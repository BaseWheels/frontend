# 🏎️ MiniGarage

<figure><img src=".gitbook/assets/banner.png" alt="MiniGarage Banner"><figcaption><p>Collect. Build. Own. - NFT Car Collection on Base</p></figcaption></figure>

## 🎯 Intro

**MiniGarage** is a Web3 gaming platform that brings the thrill of collecting die-cast cars into the blockchain era. Built on **Base Sepolia**, players can collect, trade, and truly own exclusive NFT cars through an engaging gacha system powered by MockIDRX tokens.

### Target User

- **Collectors** - Car enthusiasts who love die-cast models
- **Gamers** - Players who enjoy gacha mechanics and progression
- **Web3 Beginners** - No crypto experience needed (social login)
- **NFT Traders** - Looking for unique collectible assets

### Core Loop

```
1. Login (Email/Social) → Get Free Wallet
          ↓
2. Claim IDRX Tokens (Daily Faucet)
          ↓
3. Open Gacha Boxes → Win Cars/Fragments
          ↓
4. Collect 5 Fragments → Assemble Complete Car
          ↓
5. Trade on Marketplace or Keep Collection
```

---

## ⚠️ Problem

### 1. **No True Ownership in Traditional Games**
Players spend money on in-game items but never truly own them. When a game shuts down, all progress and purchases are lost forever.

### 2. **Complex Crypto Onboarding**
Most Web3 games require users to understand seed phrases, wallets, and gas fees - creating massive barriers for mainstream adoption.

### 3. **Lack of Collectible Gaming on Base**
Base has amazing DeFi and social apps, but lacks engaging collectible gaming experiences that bridge Web2 and Web3.

---

## ✅ Solution

### 1. **True Digital Ownership**
Every car is an NFT on Base blockchain - players fully own their assets and can trade them freely or redeem select cars for physical die-cast models.

### 2. **Seamless Onboarding with Privy**
Login with Email, Google, Twitter, or Discord. Wallet is automatically created - no seed phrases, no complexity. Perfect for Web2 users.

### 3. **Gasless UX with MockIDRX**
All in-game transactions use IDRX tokens instead of ETH. Users never worry about gas fees - just play and collect.

### 4. **Fragment Crafting System**
Collect 5 fragments (Chassis, Wheels, Engine, Body, Interior) to assemble complete cars. Adds progression and reduces pure luck dependency.

---

## 🎁 What's Included in MVP

✅ **Gacha System** - 4 tiers (Standard, Rare, Premium, Legendary) with transparent odds  
✅ **Fragment Assembly** - Collect 5 parts to forge complete car NFTs  
✅ **Inventory Management** - View cars & fragments with rarity filters  
✅ **Marketplace** - P2P trading with IDRX tokens  
✅ **Privy Auth** - Email, Google, Twitter, Discord login  
✅ **Embedded Wallet** - No MetaMask required  
✅ **Daily Faucet** - 1M IDRX every 24 hours  
✅ **Admin Buyback** - Instant sell to system for fixed prices  
✅ **Transaction History** - Track all activities  
✅ **PWA Support** - Install as mobile app  
✅ **Base Sepolia Deployment** - Fully on-chain on Base testnet  

---

## 🛠️ Built on Base

<table data-view="cards">
<thead>
<tr>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>⚡ Low Fees</strong></td>
<td>Transaction costs under $0.01</td>
</tr>
<tr>
<td><strong>🔒 Secure</strong></td>
<td>Ethereum L2 security</td>
</tr>
<tr>
<td><strong>🚀 Fast</strong></td>
<td>2-3 second confirmations</td>
</tr>
<tr>
<td><strong>🌐 Ecosystem</strong></td>
<td>Coinbase integration</td>
</tr>
</tbody>
</table>

### Why Base?

| Benefit | Description |
|---------|-------------|
| **Low Gas Fees** | Enable microtransactions for gacha boxes without eating into rewards |
| **Fast Finality** | Instant confirmation for better UX - no waiting minutes for NFT reveals |
| **Ethereum Security** | L2 settled on Ethereum mainnet for trustless security |
| **Coinbase Ecosystem** | Easy fiat on-ramps for future mainnet launch |
| **Developer Friendly** | EVM-compatible - works with existing Ethereum tools |

---

## 🔗 Quick Links

{% content-ref url="getting-started/demo-and-links.md" %}
[demo-and-links.md](getting-started/demo-and-links.md)
{% endcontent-ref %}

{% content-ref url="getting-started/user-flow.md" %}
[user-flow.md](getting-started/user-flow.md)
{% endcontent-ref %}

{% content-ref url="technical/smart-contracts.md" %}
[smart-contracts.md](technical/smart-contracts.md)
{% endcontent-ref %}

---

<p align="center">
  <b>Built with ❤️ for Base Hackathon 2026</b><br>
  <i>Judges: Feel free to reach out with questions!</i>
</p>
