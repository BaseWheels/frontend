# Table of contents

* [🏠 Overview](README.md)

## Getting Started

* [🎥 Demo & Links](getting-started/demo-and-links.md)
* [🔄 User Flow](getting-started/user-flow.md)
* [✅ Deployment on Base](getting-started/deployment-on-base.md)

## Technical

* [📜 Smart Contracts](technical/smart-contracts.md)
* [💰 IDRX Integration](technical/idrx-integration.md)
* [🏗️ Architecture](technical/architecture.md)

## Project Management

* [🗺️ Roadmap](project/roadmap.md)
* [👥 Team](project/team.md)
* [⚙️ Local Setup](project/local-setup.md)

## Resources

* [❓ FAQ](resources/faq.md)
